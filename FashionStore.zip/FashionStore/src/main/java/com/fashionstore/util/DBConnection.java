package com.fashionstore.util; // change package name if needed

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/fashion_store";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "MYSQL1@l23";

   static {
	   try
	   {
		   Class.forName("com.mysql.cj.jdbc.Driver");
	   }
	   catch (ClassNotFoundException e)
	   {
		   throw new RuntimeException("MySQL JDBC Driver not found.Check Maven Dependency.",e);
	   }
   }
   private DBConnection()
   {
   }
    public static Connection getConnection() throws SQLException{
    	return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
}
        